from pytmx.util_pygame import load_pygame
import pygame
import os, sys
from collections import OrderedDict
pygame.init()
outputSize = (512, 512)
display = pygame.display.set_mode(outputSize)
pygame.display.set_caption("TileMapTest")



class TileMap:
    def __init__(self, fileName):
        self._tmx = load_pygame(os.path.join('assets', fileName))
        print self._tmx.layers
        self.mapSize = (self._tmx.width, self._tmx.height)
        self.cellSize = (self._tmx.tilewidth, self._tmx.tileheight)
        self.solidityMap = [None] * self.getTileTotal()
        self.surfaces = OrderedDict()

        self.backgroundColor = pygame.Color(self._tmx.background_color) \
            if self._tmx.background_color \
            else (0, 0, 0, 0)

        for layer in self._tmx.visible_layers:
            self.parseLayer(layer)


    def parseLayer(self, layer):
        index = self._tmx.layers.index(layer)
        isSolid = layer.properties['solid'] == 'true' \
            if 'solid' in layer.properties \
            else False
        surfaceSize = (self.getWidthInPixels(), self.getHeightInPixels())
        tileSurface = pygame.Surface(surfaceSize).convert_alpha()
        tileSurface.fill(self.backgroundColor)

        for i in xrange(self.getTileTotal()):
            row = i / self.mapSize[0]
            column = i % self.mapSize[1]
            image = self._tmx.get_tile_image(column, row, index)
            if image != None:
                self.solidityMap[i] = self.solidityMap[i] or isSolid
                tileSurface.blit(image, (column * self.cellSize[0], row * self.cellSize[1]))

        self.surfaces[layer.name] = tileSurface

    def getSurfaces(self):
        return tuple(self.surfaces.values())

    def getSolidityMap(self):
        # For now, we make the solidityMap immutable
        return tuple(self.solidityMap)

    def isTileSolid(self, x, y):
        index = x + (y * self.getWidthInTiles())
        return self.solidityMap[index] == True

    def getTileTotal(self):
        return self.mapSize[0] * self.mapSize[1]

    def getWidthInPixels(self):
        return self.mapSize[0] * self.cellSize[0]

    def getHeightInPixels(self):
        return self.mapSize[1] * self.cellSize[1]

    def getWidthInTiles(self):
        return self.mapSize[0]

    def getHeightInTiles(self):
        return self.mapSize[1]

screen = pygame.Surface((64, 64), pygame.SRCALPHA)
screen.fill((0,0,0))
screen = screen.convert_alpha()

clock = pygame.time.Clock()
tileMap = TileMap('test.tmx')

print tileMap.isTileSolid(14, 14)

while True:
    clock.tick(60)

    # Process events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

    # Clear the screen
    screen.fill((0, 0, 0))

    surfaces =  tileMap.getSurfaces()
    for surface in surfaces:
        screen.blit(surface, (0,0))

    # Update the screen
    display.blit(pygame.transform.scale(screen, outputSize), (0, 0))
    pygame.display.flip()
