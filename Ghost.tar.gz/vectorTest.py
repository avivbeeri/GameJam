import newvector
import pygame

print (pygame.math.Vector2(), newvector.Vector2())
print (pygame.math.Vector2(1, 2), newvector.Vector2(1, 2))
print (pygame.math.Vector2((1, 2)), newvector.Vector2((1, 2)))
print (pygame.math.Vector2((2, 4)) * 2, newvector.Vector2((2, 4)) * 2)
print (pygame.math.Vector2((2, 4)) / 2, newvector.Vector2((2, 4)) / 2)
print (pygame.math.Vector2((2, 4)) + pygame.math.Vector2((2, 4)), newvector.Vector2((2, 4)) + newvector.Vector2((2, 4)))
print (pygame.math.Vector2((2, 4)) - pygame.math.Vector2((2, 4)), newvector.Vector2((2, 4)) - newvector.Vector2((2, 4)))
print (pygame.math.Vector2((2, 4)).normalize(), newvector.Vector2((2, 4)).normalize())

positionComponent = pygame.math.Vector2((2, 4))
dt = (1 / 60.0)
currentVelocity = pygame.math.Vector2((1, 0))
currentAcceleration = pygame.math.Vector2((0, 0))
positionComponent += dt * (currentVelocity + dt * currentAcceleration / 2)
print positionComponent

positionComponent = newvector.Vector2((2, 4))
dt = (1 / 60.0)
currentVelocity = newvector.Vector2((1, 0))
currentAcceleration = newvector.Vector2((0, 0))
positionComponent += dt * (currentVelocity + dt * currentAcceleration / 2)
print positionComponent
