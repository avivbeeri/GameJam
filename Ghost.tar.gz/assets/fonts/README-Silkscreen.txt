Thank you for downloading Silkscreen, a type family for your Web graphics
by Jason Kottke (jason@kottke.org).

To install the Silkscreen type family, unzip this file and drag the files
into the Fonts folder in the Control Panel.

If you encounter any problems in using this font, please email me and I'll
see if I can try and fix it. Please note that I can't help you with any
installation issues. Please consult your system's help files for assistance.

This font is free for personal and corporate use and may be redistributed in
this unmodified form on your Web site. I would ask that you not modify and
then redistribute this font...although you may modify it for your own
personal use. If you really like this font and use it often, feel free to
mail me (e- or snail mail) some small token of your appreciation. A URL
of your work using Silkscreen would be appreciated as well.

All future bug fixes, updates, and additions to the Silkscreen type family
will be available on my Web site at the following URL:

http://www.kottke.org/plus/type/silkscreen/index.html

Again, thanks for downloading Silkscreen. Enjoy!

-jason